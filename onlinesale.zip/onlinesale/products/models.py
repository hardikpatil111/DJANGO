from django.db import models
from django.urls import reverse


# Create your models here

class ProductQuerySet(models.QuerySet):
    def active(self):
        return self.filter(active=True)

class ProductManager(models.Manager):
    def get_queryset(self):
        return ProductQuerySet(self.model, using=self._db)

    def all(self):
        return self.get_queryset().active()

class Product(models.Model):
    title = models.CharField(max_length=50)
    image = models.ImageField(null=True, blank=True ,upload_to="products")
    price = models.DecimalField(default=10,max_digits=10,decimal_places=2),
    description = models.TextField(null=True)
    active = models.BooleanField(default=True)
    createdDate = models.DateField(auto_now_add=True)
    updatedDate = models.DateField(auto_now=True)

    objects = ProductManager()

    def __str__(self):
        return self.title
    
    def get_abs_url(self):
        return reverse("product:detail", kwargs={'pk':self.id}) 